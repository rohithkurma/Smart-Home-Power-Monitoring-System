# Smart Home Power Monitoring and Control System

A microcontroller-based system designed for real-time monitoring and control of household electrical loads. The system reads current sensor data and allows remote or automated switching of devices through relay modules.

## Features
- Real-time current sensing using I2C current sensors
- Load switching via relay control
- Embedded C firmware logic for load detection and actuation
- Designed with a custom 2-layer PCB for compact integration

## Technologies Used
- Embedded C
- I2C Communication Protocol
- Relay Drivers
- Custom PCB Design
