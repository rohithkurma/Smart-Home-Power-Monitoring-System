// main.c
// Smart Home Power Monitoring and Control System
// Developed using Embedded C

#include <stdio.h>
#include <stdint.h>
#include "i2c_driver.h"
#include "relay_control.h"
#include "current_sensor.h"

#define CURRENT_THRESHOLD 5.0 // Amps

void setup() {
    i2c_init();
    relay_init();
    sensor_init();
}

void loop() {
    float current = read_current_sensor();
    
    if (current > CURRENT_THRESHOLD) {
        relay_off(); // Turn off load to prevent overcurrent
    } else {
        relay_on(); // Keep load on
    }

    delay_ms(1000); // Sample every 1 second
}

int main() {
    setup();
    while(1) {
        loop();
    }
    return 0;
}
